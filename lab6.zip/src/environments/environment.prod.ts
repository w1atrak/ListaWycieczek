export const environment = {
  production: true,
  firebaseConfig :{
    apiKey: "AIzaSyCEu0Rd318kxnqLeloyqdZCmgCiONCtzkc",
  authDomain: "wycieczki-eefdc.firebaseapp.com",
  databaseURL: "https://wycieczki-eefdc-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "wycieczki-eefdc",
  storageBucket: "wycieczki-eefdc.appspot.com",
  messagingSenderId: "244318825152",
  appId: "1:244318825152:web:81396e0e9b9a31b144db25",
  measurementId: "G-QLTWDPJ1TQ"
  }
};
