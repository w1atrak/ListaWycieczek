// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig :{
    apiKey: "AIzaSyCEu0Rd318kxnqLeloyqdZCmgCiONCtzkc",
  authDomain: "wycieczki-eefdc.firebaseapp.com",
  databaseURL: "https://wycieczki-eefdc-default-rtdb.europe-west1.firebasedatabase.app",
   
  projectId: "wycieczki-eefdc",
  storageBucket: "wycieczki-eefdc.appspot.com",
  messagingSenderId: "244318825152",
  appId: "1:244318825152:web:81396e0e9b9a31b144db25",
  measurementId: "G-QLTWDPJ1TQ"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
